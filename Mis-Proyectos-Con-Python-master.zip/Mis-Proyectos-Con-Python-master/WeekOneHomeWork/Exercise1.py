mb = 1024
print('En 8 MB existen: ' , (8*mb) , 'bytes.')