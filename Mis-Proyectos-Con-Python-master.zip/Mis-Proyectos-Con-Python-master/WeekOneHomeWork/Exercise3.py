w=7
h=4
perRectangulo=2*w+2*h
print('El perimetro del rectangulo es: ',perRectangulo,'cm.')