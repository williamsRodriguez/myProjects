minuto,segundo=60,60
print('En 15 horas,30 minutos y 45 segundos existen: ', ((15*minuto*segundo)+(30*segundo)+45),' segundos.')